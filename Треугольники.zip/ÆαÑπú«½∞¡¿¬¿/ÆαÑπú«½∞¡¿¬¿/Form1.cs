using System.CodeDom.Compiler;
using System.Diagnostics.Eventing.Reader;

namespace Треугольники
{
    public partial class Form1 : Form
    {
        class Triangle
        {
            Point p1, p2, p3;
            private List<LineSegment> lineSegments;
            private double a, b, c;
            public Triangle(Point p1, Point p2, Point p3)
            {
                this.p1 = p1;
                this.p2 = p2;
                this.p3 = p3;

                lineSegments =
                [
                    new LineSegment(p1, p2),
                    new LineSegment(p2, p3),
                    new LineSegment(p3, p1),
                ];

                findABC();
            }

            public Point P1
            {
                get{ return p1; }

                set { p1 = value;}
            }

            public Point P2
            {
                get { return p2; }

                set { p2 = value; }
            }

            public Point P3
            {
                get { return p3; }
                set { p3 = value;}
            }

            private void findABC()
            {
                this.a = Math.Sqrt(Math.Pow((p1.X - p2.X), 2) + Math.Pow((p1.Y - p2.Y), 2));
                this.b = Math.Sqrt(Math.Pow((p2.X - p3.X), 2) + Math.Pow((p2.Y - p3.Y), 2));
                this.c = Math.Sqrt(Math.Pow((p1.X - p3.X), 2) + Math.Pow((p1.Y - p3.Y), 2));
            }


            public List<LineSegment> LineSegments
            {
                get { return lineSegments; }

                set { lineSegments = value; }
            }

            public double getPerimeter()
            {
                return a + b + c;
            }

            public double getArea()
            {
                double P, p;
                double s;
                P = getPerimeter();
                p = P / 2;

                s = Math.Sqrt(p * (p - a) * (p - b) * (p - c));

                return s;
            }


        }

        class LineSegment
        {
            private Point p1, p2;

            public LineSegment(Point p1, Point p2)
            {
                this.p1 = p1;
                this.p2 = p2;
            }

            public Point P1
            {
                get { return p1; }

                set { p1 = value; }
            }

            public Point P2
            {
                get {  return p2; }

                set { p2 = value; }
            }
        }

        Point[] points;
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "0";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            triangleInit();
        }

        private void triangleInit()
        {
            int dotCount = int.Parse(textBox1.Text);
            int triangleCount;
            if (dotCount % 3 == 0)
                triangleCount = dotCount / 3;
            else
            {
                MessageBox.Show("Введите число кратное трём");
                return;
            }

            Random rdm = new Random();
            int val;
            Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            var tr = new List<Triangle>();
            var notIntersectinTriangles = new List<List<Triangle>>();
            var areas = new List<double>();

            points = new Point[dotCount];
            /*  {new Point(432, 360),
              new Point(68, 412),
              new Point(318, 254),
              new Point(564, 267),
              new Point(344, 444),
              new Point(11, 362),
              new Point(378, 237),
              new Point(115, 32),
              new Point(331, 196),
              };*/

            for (int j = 0; j < dotCount; j++)
            {
                val = rdm.Next(pictureBox1.Width);
                points[j].X = val;

                val = rdm.Next(pictureBox1.Height);
                points[j].Y = val;
            }

            var list1 = new List<string>();
            for (int i = 0; i < dotCount; i++)
            {
                list1.Add(i.ToString());
            }

            FindAreas(list1, points.ToList(), ref areas, ref notIntersectinTriangles, ref tr);
           
            int minAreaIndex = areas.IndexOf(areas.Min());

           
            Point[] finalPoints = new Point[3];
            for (int j = 0; j < triangleCount; j++)
            {
                finalPoints[0] = notIntersectinTriangles[minAreaIndex][j].P1;
                finalPoints[1] = notIntersectinTriangles[minAreaIndex][j].P2;
                finalPoints[2] = notIntersectinTriangles[minAreaIndex][j].P3;
                using (Graphics grfx = Graphics.FromImage(bmp))
                {
                    // Рисуем.
                    //grfx.Clear(Color.White);
                    grfx.DrawPolygon(Pens.Black, finalPoints);
                }
            }
            pictureBox1.Image = bmp;




        }


        void FindAreas(List<string> values, List<Point> points, ref List<double> area, ref List<List<Triangle>> notIntersectinTriangles, ref List<Triangle> tr)
        {
            int triangleCount = int.Parse(textBox1.Text) / 3;
            bool isIntersecting = false;
            var combinations = GetCombinations(values, 3).ToList();
            int div = values.Count / 3;

            if (combinations.Count > 1 || combinations.Count == triangleCount)
                combinations.RemoveRange((combinations.Count / div), combinations.Count - (combinations.Count / div));

            foreach (var combination in combinations)
            {
                int pInd1 = int.Parse(combination.ElementAt(0));
                int pInd2 = int.Parse(combination.ElementAt(1));
                int pInd3 = int.Parse(combination.ElementAt(2));


                var values2 = values.Except(combination).ToList();


                tr.Add(new Triangle(points[pInd1], points[pInd2], points[pInd3]));

                if (tr.Count > 1 || tr.Count == triangleCount)
                {
                    for (int a = 0; a < tr.Count - 1; a++)
                    {
                        for (int b = a + 1; b < tr.Count; b++)
                        {
                            isIntersecting = IsTriangleTriangleIntersecting(tr[a], tr[b]);
                            if (isIntersecting)
                                goto skip;
                        }
                    }

                

                    if (!isIntersecting && tr.Count == triangleCount)
                    {
                        notIntersectinTriangles.Add(new List<Triangle>(tr));
                        double tempArea = 0;
                        var notIntersectinTr = notIntersectinTriangles.Last();
                        foreach (var trg in notIntersectinTr)
                        {
                            tempArea += trg.getArea();
                        }
                        area.Add(tempArea);


                    }
                }

                

                FindAreas(values2, points, ref area, ref notIntersectinTriangles, ref tr);
                skip:;

                tr.RemoveAt(tr.Count - 1);
            }
          
        }
/*        public bool isTriangle(Point p1, Point p2, Point p3)
        {


            double a, b, c;


            a = Math.Sqrt(Math.Pow((p1.X - p2.X), 2) + Math.Pow((p1.Y - p2.Y), 2));
            b = Math.Sqrt(Math.Pow((p2.X - p3.X), 2) + Math.Pow((p2.Y - p3.Y), 2));
            c = Math.Sqrt(Math.Pow((p1.X - p3.X), 2) + Math.Pow((p1.Y - p3.Y), 2));

            bool isTriangle = false;
            if ((a < b + c) && (b < a + c) && (c < a + b))
                isTriangle = true;
            return isTriangle;
        }
*/
        private bool IsTriangleTriangleIntersecting(Triangle triangle1, Triangle triangle2)
        {
            bool isIntersecting = false;

            //Step 1. AABB intersection
            if (isIntersectingAABB(triangle1, triangle2))
            {
                //Step 2. Line segment - triangle intersection
                if (AreAnyLineSegmentsIntersecting(triangle1, triangle2))
                {
                    isIntersecting = true;
                }
                //Step 3. Point in triangle intersection - if one of the triangles is inside the other
                else if (AreCornersIntersecting(triangle1, triangle2))
                {
                    isIntersecting = true;
                }
            }

            return isIntersecting;
        }
        private bool isIntersectingAABB(Triangle t1, Triangle t2)
        {

            //Треугольник 1
            float t1_minX = Math.Min(t1.P1.X, Math.Min(t1.P2.X, t1.P3.X));
            float t1_maxX = Math.Max(t1.P1.X, Math.Max(t1.P2.X, t1.P3.X));
            float t1_minY = Math.Min(t1.P1.Y, Math.Min(t1.P2.Y, t1.P3.Y));
            float t1_maxY = Math.Max(t1.P1.Y, Math.Max(t1.P2.Y, t1.P3.Y));


            //Треугольник 2
            float t2_minX = Math.Min(t2.P1.X, Math.Min(t2.P2.X, t2.P3.X));
            float t2_maxX = Math.Max(t2.P1.X, Math.Max(t2.P2.X, t2.P3.X));
            float t2_minY = Math.Min(t2.P1.Y, Math.Min(t2.P2.Y, t2.P3.Y));
            float t2_maxY = Math.Max(t2.P1.Y, Math.Max(t2.P2.Y, t2.P3.Y));

            bool isIntersecting = true;

            if (t1_minX > t2_maxX)
            {
                isIntersecting = false;
            }
            else if (t2_minX > t1_maxX)
            {
                isIntersecting = false;
            }
            //Z axis
            else if (t1_minY > t2_maxY)
            {
                isIntersecting = false;
            }
            else if (t2_minY > t1_maxY)
            {
                isIntersecting = false;
            }

            return isIntersecting;
        }

        bool AreAnyLineSegmentsIntersecting(Triangle t1, Triangle t2)
        {
            bool isIntersecting = false;

            //Loop through all edges
            for (int i = 0; i < t1.LineSegments.Count(); i++)
            {
                for (int j = 0; j < t2.LineSegments.Count(); j++)
                {
                    //The start/end coordinates of the current line segments
                    Point t1_p1 = t1.LineSegments[i].P1;
                    Point t1_p2 = t1.LineSegments[i].P2;
                    Point t2_p1 = t2.LineSegments[j].P1;
                    Point t2_p2 = t2.LineSegments[j].P2;

                    //Are they intersecting?
                    if (AreLineSegmentsIntersecting(t1_p1, t1_p2, t2_p1, t2_p2))
                    {
                        isIntersecting = true;

                        //To stop the outer for loop
                        i = int.MaxValue - 1;

                        break;
                    }
                }
            }

            return isIntersecting;
        }

        bool AreLineSegmentsIntersecting(Point p1, Point p2, Point p3, Point p4)
        {
            bool isIntersecting = false;

            float denominator = (p4.Y - p3.Y) * (p2.X - p1.X) - (p4.X - p3.X) * (p2.Y - p1.Y);

            //Make sure the denominator is != 0, if 0 the lines are parallel
            if (denominator != 0)
            {
                float u_a = ((p4.X - p3.X) * (p1.Y - p3.Y) - (p4.Y - p3.Y) * (p1.X - p3.X)) / denominator;
                float u_b = ((p2.X - p1.X) * (p1.Y - p3.Y) - (p2.Y - p1.Y) * (p1.X - p3.X)) / denominator;

                //Is intersecting if u_a and u_b are between 0 and 1
                if (u_a >= 0 && u_a <= 1 && u_b >= 0 && u_b <= 1)
                {
                    isIntersecting = true;
                }
            }

            return isIntersecting;
        }



        bool AreCornersIntersecting(Triangle t1, Triangle t2)
        {
            bool isIntersecting = false;

            //We only have to test one corner from each triangle
            //Triangle 1 in triangle 2
            if (IsPointInTriangle(t1.P1, t2.P1, t2.P2, t2.P3))
            {
                isIntersecting = true;
            }
            //Triangle 2 in triangle 1
            else if (IsPointInTriangle(t2.P1, t1.P1, t1.P2, t1.P3))
            {
                isIntersecting = true;
            }

            return isIntersecting;
        }

        bool IsPointInTriangle(Point p, Point p1, Point p2, Point p3)
        {
            bool isWithinTriangle = false;

            float denominator = ((p2.Y - p3.Y) * (p1.X - p3.X) + (p3.X - p2.X) * (p1.Y - p3.Y));

            float a = ((p2.Y - p3.Y) * (p.X - p3.X) + (p3.X - p2.X) * (p.Y - p3.Y)) / denominator;
            float b = ((p3.Y - p1.Y) * (p.X - p3.X) + (p1.X - p3.X) * (p.Y - p3.Y)) / denominator;
            float c = 1 - a - b;

            //The point is within the triangle if 0 <= a <= 1 and 0 <= b <= 1 and 0 <= c <= 1
            if (a >= 0f && a <= 1f && b >= 0f && b <= 1f && c >= 0f && c <= 1f)
            {
                isWithinTriangle = true;
            }

            return isWithinTriangle;
        }

        static IEnumerable<IEnumerable<T>> GetCombinations<T>(IEnumerable<T> items, int count)
        {
            int i = 0;
            foreach (var item in items)
            {
                if (count == 1)
                    yield return new T[] { item };
                else
                {
                    foreach (var result in GetCombinations(items.Skip(i + 1), count - 1))
                        yield return new T[] { item }.Concat(result);
                }

                ++i;
            }
        }


        private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}